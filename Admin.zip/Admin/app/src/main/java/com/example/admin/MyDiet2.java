package com.example.admin;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MyDiet2 extends AppCompatActivity {

    Button k;
    TextView b1,b2,b3;
    TextView l1,l2,l3;
    TextView d1,d2,d3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_diet2);

        k=(Button)findViewById(R.id.dietDonebtn);
        b1=(TextView)findViewById(R.id.breakfastdiet1);
        b2=(TextView)findViewById(R.id.breakfastdiet2);
        b3=(TextView)findViewById(R.id.breakfastdiet3);
        l1=(TextView)findViewById(R.id.lunchdiet1);
        l2=(TextView)findViewById(R.id.lunchdiet2);
        l3=(TextView)findViewById(R.id.lunchdiet3);
        d1=(TextView)findViewById(R.id.dinnerdiet1);
        d2=(TextView)findViewById(R.id.dinnerdiet2);
        d3=(TextView)findViewById(R.id.dinnerdiet3);

        k.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent ok=new Intent(MyDiet2.this,My_Diet.class);
                startActivity(ok);
            }
        });

        BottomNavigationView bottomNavigationView=findViewById(R.id.bottom_navigation);
        bottomNavigationView.setSelectedItemId(R.id.home_nav);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull @org.jetbrains.annotations.NotNull MenuItem menuItem) {
                switch (menuItem.getItemId())
                {
                    case R.id.home_nav:
                        startActivity(new Intent(getApplicationContext(),user_home.class));
                        overridePendingTransition(0,0);
                        return true;

                    case R.id.profile_nav:
                        startActivity(new Intent(getApplicationContext(),My_Profile.class));
                        overridePendingTransition(0,0);
                        return true;
/*
                    case R.id.tips_nav:
                        startActivity(new Intent(getApplicationContext(),Tips.class));
                        overridePendingTransition(0,0);
                        return true;
*/
                    case R.id.logout_nav:
                        startActivity(new Intent(getApplicationContext(),MainActivity.class));
                        overridePendingTransition(0,0);
                        return true;

                }
                return false;
            }
        });
    }
}