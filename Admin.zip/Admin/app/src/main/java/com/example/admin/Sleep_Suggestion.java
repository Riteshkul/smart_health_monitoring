package com.example.admin;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class Sleep_Suggestion extends AppCompatActivity {

    public  Button sug;
    public  TextView sd,sat,wat;
    public EditText user_age;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sleep_suggestion);

        user_age=(EditText)findViewById(R.id.sleep_age);
        sug=(Button)findViewById(R.id.sleep_suggest);
        sd=(TextView)findViewById(R.id.sleep_duration);
        sat=(TextView)findViewById(R.id.sleep_at_time);
        wat=(TextView)findViewById(R.id.wake_up_time);

        int age=Integer.parseInt(user_age.getText().toString());
        sug.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                user_age.setText("");
                if ((age >= 16) && (age <= 18)) {
                    sd.setText(" 8 hours");
                    sat.setText(" 10:00 pm");
                    wat.setText(" 6:00 am");
                } else if ((age >= 18) && (age <= 30)) {
                    sd.setText(" 7.5 hours");
                    sat.setText(" 10:00 pm");
                    wat.setText(" 5:30 am");
                } else if ((age >= 30) && (age <= 50)) {
                    sd.setText(" 7 hours");
                    sat.setText(" 10:00 pm");
                    wat.setText(" 5:00 am");
                } else if ((age >= 50) && (age <= 65)) {
                    sd.setText(" 7 hours");
                    sat.setText(" 10:00 pm");
                    wat.setText(" 5:00 am");
                } else if (age > 65) {
                    sd.setText(" 7.5 hours");
                    sat.setText(" 10:00 pm");
                    wat.setText(" 5:30 am");
                }
            }
        });
        BottomNavigationView bottomNavigationView=findViewById(R.id.bottom_navigation);
        bottomNavigationView.setSelectedItemId(R.id.home_nav);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull @org.jetbrains.annotations.NotNull MenuItem menuItem) {
                switch (menuItem.getItemId())
                {
                    case R.id.home_nav:
                        startActivity(new Intent(getApplicationContext(),user_home.class));
                        overridePendingTransition(0,0);
                        return true;

                    case R.id.profile_nav:
                        startActivity(new Intent(getApplicationContext(),My_Profile.class));
                        overridePendingTransition(0,0);
                        return true;


                    case R.id.logout_nav:
                        startActivity(new Intent(getApplicationContext(),MainActivity.class));
                        overridePendingTransition(0,0);
                        return true;

                }
                return false;
            }
        });
    }
}