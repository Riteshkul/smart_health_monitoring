package com.example.admin;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class My_Diet extends AppCompatActivity {

    Button mydiet;
    TextView target,bodyType;
    int t,b;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_diet);

        mydiet=(Button)findViewById(R.id.btnviewMyDiet);
        target=(TextView)findViewById(R.id.textTarget);
        bodyType=(TextView)findViewById(R.id.textBodyType);


        mydiet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent d=new Intent(My_Diet.this,MyDiet2.class);
                startActivity(d);

                String tar=(String)target.getText();
                String btype=(String)bodyType.getText();

                if(tar.equalsIgnoreCase("Loss Weight"))
                {
                    t=1;
                }
                else if(tar.equalsIgnoreCase("Maintain Weight"))
                {
                    t=2;
                }
                else if(tar.equalsIgnoreCase("Gain Weight"))
                {
                    t=3;
                }
                else
                {
                    t=0;

                }

                if(btype.equalsIgnoreCase("Normal"))
                {
                    b=1;
                }
                else if(btype.equalsIgnoreCase("Obesed"))
                {
                    b=2;
                }
                else if(btype.equalsIgnoreCase("Extremely Obesed"))
                {
                    b=3;
                }
                else
                {
                    b=0;
                }

            }
        });

        BottomNavigationView bottomNavigationView=findViewById(R.id.bottom_navigation);
        bottomNavigationView.setSelectedItemId(R.id.home_nav);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull @org.jetbrains.annotations.NotNull MenuItem menuItem) {
                switch (menuItem.getItemId())
                {
                    case R.id.home_nav:
                        startActivity(new Intent(getApplicationContext(),user_home.class));
                        overridePendingTransition(0,0);
                        return true;

                    case R.id.profile_nav:
                        startActivity(new Intent(getApplicationContext(),My_Profile.class));
                        overridePendingTransition(0,0);
                        return true;
/*
                    case R.id.tips_nav:
                        startActivity(new Intent(getApplicationContext(),Tips.class));
                        overridePendingTransition(0,0);
                        return true;
*/
                    case R.id.logout_nav:
                        startActivity(new Intent(getApplicationContext(),MainActivity.class));
                        overridePendingTransition(0,0);
                        return true;

                }
                return false;
            }
        });
    }
}