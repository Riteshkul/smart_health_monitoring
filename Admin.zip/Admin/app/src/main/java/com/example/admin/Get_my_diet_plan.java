package com.example.admin;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class Get_my_diet_plan extends AppCompatActivity {
Button get_plan;
TextView tv;
EditText get_target,get_bmi,get_bmr,get_bfp,get_body_type;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_get_my_diet_plan);
        get_target=findViewById(R.id.target);
        get_bmi=findViewById(R.id.bmi);
        get_bmr=findViewById(R.id.bmr);
        get_body_type=findViewById(R.id.body_type);
        get_bfp=findViewById(R.id.bfp);
        get_plan=findViewById(R.id.View_my_plan);
        get_plan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String url = "https://diet-api-android.herokuapp.com/?target="+get_target.getText()+"&bmi="+get_bmi.getText()
                        +"&bmr="+get_bmr.getText()+"&body_type="+get_body_type.getText()+"&bfp="+get_bfp.getText();
                RequestQueue queue = Volley.newRequestQueue(Get_my_diet_plan.this);

                JsonObjectRequest jsonObjectRequest = new JsonObjectRequest
                        (Request.Method.GET, url, null, new Response.Listener<JSONObject>() {

                            @Override
                            public void onResponse(JSONObject response) {
                                try {
                                    String result=response.getString("prediction");
                                    Intent i=new Intent(Get_my_diet_plan.this,view_my_plan.class);
                                    //i.putExtra("Prediction " , result.toString());
                                    i.putExtra("Prediction " , result.toString());
                                    //i.putExtra("bmi",get_bmi.toString());
                                    startActivity(i);

                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            }
                        }, new Response.ErrorListener() {

                            @Override
                            public void onErrorResponse(VolleyError error) {
                                // TODO: Handle error
                                Toast.makeText(Get_my_diet_plan.this,"Error",Toast.LENGTH_SHORT).show();
                            }
                        });

// Access the RequestQueue through your singleton class.
                queue.add(jsonObjectRequest);


            }
        });
    }
}