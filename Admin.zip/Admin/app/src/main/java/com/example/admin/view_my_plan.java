package com.example.admin;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import org.jetbrains.annotations.NotNull;

public class view_my_plan extends AppCompatActivity {
String plan_name="";
String fire_breakfast,fire_lunch,fire_dinner;
TextView status_bmi,food_breakfast,food_lunch,food_dinner,label_status,label_breakfast,label_lunch,label_dinner;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_my_plan);
        status_bmi=findViewById(R.id.bmi_status);
        food_breakfast=findViewById(R.id.breakfast_items);
        label_status=findViewById(R.id.status);
        label_breakfast=findViewById(R.id.breakfast);
        label_lunch=findViewById(R.id.lunch);
        label_dinner=findViewById(R.id.dinner);
        label_status=findViewById(R.id.status);
        food_lunch=findViewById(R.id.lunch_items);
        food_dinner=findViewById(R.id.dinner_items);
        //String plan_number=getIntent().getStringExtra("Prediction");
        String plan_number="4";
        if(plan_number.toString().equals("0") || plan_number.toString().equals("1"))
        {
            plan_name+="balance_diet";
        }
        else if(plan_number.toString().equals("2"))
        {
            plan_name+="high_carbo_diet";
        }
        else if(plan_number.toString().equals("3"))
        {
            plan_name+="ketogenic_diet";
        }
        else if(plan_number.toString().equals("4"))
        {
            plan_name+="low_carbo_diet";
        }
        else
        {
            plan_name+="zone_diet";
        }
        DatabaseReference reference;
        reference= FirebaseDatabase.getInstance().getReference(plan_name.toString());
        reference.get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
            @Override
            public void onComplete(@NonNull @NotNull Task<DataSnapshot> task) {
                if (task.isSuccessful()) {
                    if (task.getResult().exists()) {

                        DataSnapshot dataSnapshot = task.getResult();
                        fire_breakfast = String.valueOf(dataSnapshot.child("breakfast").getValue());
                        fire_lunch = String.valueOf(dataSnapshot.child("lunch").getValue());
                        fire_dinner = String.valueOf(dataSnapshot.child("dinner").getValue());
                        food_breakfast.setText(fire_breakfast);
                        food_lunch.setText(fire_lunch);
                        food_dinner.setText(fire_dinner);
                    }
                }
            }
        });
        //get_status();
    }

    private void get_status() {
        Double bmi_level=Double.parseDouble(getIntent().getStringExtra("bmi"));
        String level="";
        if(bmi_level<18.5)
        {
            level+="Underweight";
        }
       else if(bmi_level>18.5 && bmi_level<24.9 )
        {
            level+="Normal";
        }
        else if(bmi_level>25.0 && bmi_level<29.9 )
        {
            level+="Overweight";
        }
        else
        {
            level+="Obese";
        }
        status_bmi.setText(level);
    }


}