package com.example.admin;

public class add_user_helper {
    String email, name, add, phoneno,age;

    public add_user_helper() {

    }

    public add_user_helper(String email, String name, String add, String age, String phoneno) {
        this.email = email;
        this.name = name;
        this.add = add;
        this.age = age;
        this.phoneno = phoneno;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAdd() {
        return add;
    }

    public void setAdd(String add) {
        this.add = add;
    }

    public String getPhoneno() {
        return phoneno;
    }

    public void setPhoneno(String phoneno) {
        this.phoneno = phoneno;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }
}