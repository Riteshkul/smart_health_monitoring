package com.example.admin;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.util.UUID;

public class Add_Excercise extends AppCompatActivity implements View.OnClickListener{
    BottomNavigationView bottomNavigationView;
    Button btn_upload,submit;
    int SELECT_PICTURE=200;
    Uri selectedimageuri;
    String selected="";
    RadioGroup radioGp;
    RadioButton radioButton;
    FirebaseDatabase rootnode;
    FirebaseStorage storage;
    StorageReference storageReference;
    DatabaseReference reference;
    EditText name,info;
    ImageView tv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add__excercise);
        btn_upload=findViewById(R.id.btn_upload);
        btn_upload.setOnClickListener(this);
        name=findViewById(R.id.excercise_name);
        info=findViewById(R.id.excercise_info);
        radioButton=findViewById(R.id.radioButton6);
        radioGp=findViewById(R.id.radioGroup);
        submit=findViewById(R.id.submit);
        submit.setOnClickListener(this);
tv=findViewById(R.id.imageView6);
        bottomNavigationView=findViewById(R.id.bottom_nav);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Intent i;
                switch(item.getItemId())
                {
                    case R.id.logout:
                        FirebaseAuth.getInstance().signOut();
                        Intent intent=new Intent(Add_Excercise.this,login_activity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                        break;
                    case R.id.home:
                        i=new Intent(getApplicationContext(),MainActivity.class);
                        startActivity(i);
                        overridePendingTransition(0,0);
                        break;

                }
                return false;
            }
        });
        radioGp.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                switch(i){
                    case R.id.radioButton5:
                        selected+="Loose Weight";
                        break;
                    case R.id.radioButton6:
                        selected+="Maintain Weight";
                        break;
                    case R.id.radioButton10:
                        selected+="Gain Muscle";
                        break;
                }
            }
        });
    }

    @Override
    public void onClick(View v) {
        switch(v.getId())
        {
            case R.id.btn_upload:
                imagechooser();
                break;
            case R.id.submit:
                insert();
                break;
        }

    }


    private void imagechooser() {
        Intent i=new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.INTERNAL_CONTENT_URI);
        startActivityForResult(i,SELECT_PICTURE);
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode,  Intent data) {
        if(resultCode==RESULT_OK)
        {
            if(requestCode==SELECT_PICTURE)
            {
                selectedimageuri=data.getData();
                if(null!=selectedimageuri)
                    tv.setImageURI(selectedimageuri);
            }
        }
        else
        {
            Toast.makeText(this,"Problem",Toast.LENGTH_SHORT).show();
        }
        super.onActivityResult(requestCode, resultCode, data);
    }
    private void insert() {
        final String nm=name.getText().toString();
        final String in=info.getText().toString();


        if (TextUtils.isEmpty(nm)){
            name.setError("please enter Name");
        }
        else if (TextUtils.isEmpty(in)) {
            info.setError("please enter information");
        }
        else if (TextUtils.isEmpty(selected)) {
            radioButton.setError("please select type");
        }
        else if (tv.getDrawable()==null) {
            Toast.makeText(this,"Please select the image",Toast.LENGTH_SHORT).show();
        }
        else
        {
            storage = FirebaseStorage.getInstance();
            storageReference = storage.getReference();
            rootnode=FirebaseDatabase.getInstance();
            reference=rootnode.getReference("Excercises");


            DatabaseReference fbDb = null;
            if (fbDb == null) {
                fbDb = FirebaseDatabase.getInstance().getReference();
            }
            fbDb.child("Excercises/"+selected)
                    .addListenerForSingleValueEvent(new ValueEventListener() {
                                                        @Override
                                                        public void onDataChange(DataSnapshot dataSnapshot) {
                                                            // get total available quest
                                                            int size = (int) dataSnapshot.getChildrenCount();
                                                            int x=size+1;

                                                            add_excercise_helper addExcerseHelper=new add_excercise_helper(nm,in);
                                                            reference.child(selected).child("Excercise"+x).setValue(addExcerseHelper);

                                                        }
                                                        @Override
                                                        public void onCancelled(DatabaseError databaseError) {

                                                        }

                                                    }
                    );
            if (selectedimageuri != null) {

                // Code for showing progressDialog while uploading
                ProgressDialog progressDialog
                        = new ProgressDialog(this);
                progressDialog.setTitle("Uploading...");
                progressDialog.show();

                // Defining the child of storageReference
                StorageReference ref
                        = storageReference
                        .child(
                                "Excercise_images/"+selected+"/"
                                        +name.getText().toString());

                // adding listeners on upload
                // or failure of image
                ref.putFile(selectedimageuri)
                        .addOnSuccessListener(
                                new OnSuccessListener<UploadTask.TaskSnapshot>() {

                                    @Override
                                    public void onSuccess(
                                            UploadTask.TaskSnapshot taskSnapshot)
                                    {

                                        // Image uploaded successfully
                                        // Dismiss dialog
                                        progressDialog.dismiss();
                                        Toast.makeText(getApplicationContext(),"Image Uploaded",Toast.LENGTH_SHORT).show();
                                    }
                                })

                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e)
                            {

                                // Error, Image not uploaded
                                progressDialog.dismiss();
                                Toast
                                        .makeText(getApplicationContext(),
                                                "Failed " + e.getMessage(),
                                                Toast.LENGTH_SHORT)
                                        .show();
                            }
                        })
                        .addOnProgressListener(
                                new OnProgressListener<UploadTask.TaskSnapshot>() {

                                    // Progress Listener for loading
                                    // percentage on the dialog box
                                    @Override
                                    public void onProgress(
                                            UploadTask.TaskSnapshot taskSnapshot)
                                    {
                                        double progress
                                                = (100.0
                                                * taskSnapshot.getBytesTransferred()
                                                / taskSnapshot.getTotalByteCount());
                                        progressDialog.setMessage(
                                                "Uploaded "
                                                        + (int)progress + "%");
                                    }
                                });
            }

            Toast.makeText(this,"Excercise added successfully",Toast.LENGTH_SHORT).show();
            tv.setImageURI(null);
            name.setText("");
            info.setText("");
            radioGp.setSelected(false);
        }
    }

    private class add_excercise_helper {
        String name,info;
        public add_excercise_helper() {
        }
        public add_excercise_helper(String nm,String in) {
            this.name=nm;
            this.info=in;

        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getInfo() {
            return info;
        }

        public void setInfo(String info) {
            this.info = info;
        }

    }
}
