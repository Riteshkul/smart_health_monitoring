package com.example.admin;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class insert_items extends AppCompatActivity {
EditText diet_plan_name,diet_category,food_items;
Button b1;
    FirebaseDatabase rootnode;
    DatabaseReference reference;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insert_items);
        diet_plan_name=findViewById(R.id.plan);
        diet_category=findViewById(R.id.category);
        food_items=findViewById(R.id.items);
        b1=findViewById(R.id.button);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                rootnode=FirebaseDatabase.getInstance();
                reference=rootnode.getReference(diet_plan_name.getText().toString());
                reference.child(diet_category.getText().toString()).setValue(food_items.getText().toString());
                Toast.makeText(insert_items.this,"inserted",Toast.LENGTH_SHORT).show();
            }
        });
    }
}