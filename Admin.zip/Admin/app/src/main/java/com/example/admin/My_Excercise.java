package com.example.admin;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class My_Excercise extends AppCompatActivity {

    ListView listView;
    String mtitle[]={"Ex1","Ex2","Ex3","Ex4","Ex5"};
    String mdescription[]={"Ex1 description","Ex2 description","Ex3 description","Ex4 description","Ex4 description"};
    int image[]={R.drawable.myexcersise,R.drawable.mybmi,R.drawable.mydiet,R.drawable.mytips,R.drawable.mysleep};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_excercise);

        listView =findViewById(R.id.listview_excercise);
        MyAdapter adapter=new MyAdapter(this,mtitle,mdescription,image);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if(position == 0)
                {
                    Toast.makeText(My_Excercise.this,"Ex1 description",Toast.LENGTH_SHORT).show();
                }
                if(position == 1)
                {
                    Toast.makeText(My_Excercise.this,"Ex2 description",Toast.LENGTH_SHORT).show();
                }
                if(position == 2)
                {
                    Toast.makeText(My_Excercise.this,"Ex3 description",Toast.LENGTH_SHORT).show();
                }
                if(position == 3)
                {
                    Toast.makeText(My_Excercise.this,"Ex4 description",Toast.LENGTH_SHORT).show();
                }
                if(position == 4)
                {
                    Toast.makeText(My_Excercise.this,"Ex5 description",Toast.LENGTH_SHORT).show();
                }
            }
        });

        BottomNavigationView bottomNavigationView=findViewById(R.id.bottom_navigation);
        bottomNavigationView.setSelectedItemId(R.id.home_nav);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull @org.jetbrains.annotations.NotNull MenuItem menuItem) {
                switch (menuItem.getItemId())
                {
                    case R.id.home_nav:
                        startActivity(new Intent(getApplicationContext(),user_home.class));
                        overridePendingTransition(0,0);
                        return true;

                    case R.id.profile_nav:
                        startActivity(new Intent(getApplicationContext(),My_Profile.class));
                        overridePendingTransition(0,0);
                        return true;
/*
                    case R.id.tips_nav:
                        startActivity(new Intent(getApplicationContext(),Tips.class));
                        overridePendingTransition(0,0);
                        return true;
*/
                    case R.id.logout_nav:
                        startActivity(new Intent(getApplicationContext(),MainActivity.class));
                        overridePendingTransition(0,0);
                        return true;



                }
                return false;
            }
        });
    }

    class MyAdapter extends ArrayAdapter<String>
    {
        Context context;
        String extitle[];
        String edescription[];
        int eimg[];

        MyAdapter (Context c,String title[],String description[],int img[])
        {
            super(c,R.layout.row,R.id.excercise_main_title,title);
           // this.context=O;
            this.extitle=title;
            this.edescription=description;
            this.eimg=img;

        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent)
        {
            LayoutInflater layoutInflater=(LayoutInflater)getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View row = layoutInflater.inflate(R.layout.row,parent,false);
            ImageView img1=row.findViewById(R.id.excercise1);
            TextView myTitle=row.findViewById(R.id.excercise_main_title);
            TextView myDescription=row.findViewById(R.id.excercise_sub_title);

            img1.setImageResource(eimg[position]);
            myTitle.setText(extitle[position]);
            myDescription.setText(edescription[position]);
            return row;


        }
    }
}